package com.educacionit.clase3;

import com.educacionit.clase3.modelos.Vuelo;

public class AppPrincipal {

	public static void main(String[] args) {
		
		Vuelo v678 = new Vuelo();
		Vuelo v666 = new Vuelo('A');
		Vuelo v555 = new Vuelo(555);
	}

}
