package com.educacionit.clase3.modelos;

public class VueloCarga {

}
