package com.educacionit.ejercicio4;

public class AppPrincipal {
	public static void main(String[] args) {
		// mostramos los numeros pares de 0 al 100

//		int x = 100;
//		while (x >= 0) { // LOOP INFINITO
//
//			System.out.println(x);
//			// x = x + 2 ;
//			x -= 2;
//
//		}

		for (int y = 100; y >= 0; y -= 2) {
			System.out.println(y);
		}

	}

}
