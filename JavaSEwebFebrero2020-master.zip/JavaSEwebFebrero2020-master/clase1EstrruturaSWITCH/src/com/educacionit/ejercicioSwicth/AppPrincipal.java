package com.educacionit.ejercicioSwicth;

import java.util.Scanner;

import javax.swing.JOptionPane;

 class AppPrincipal {

	public static void main(String[] args) {
	
		// creamos una instancia de la clase calculadora2
		Calculadora2 cl = new Calculadora2();
		// invocamos a los metodos mediante el objeto "cl"
		cl.solicitarNumeros();
		
		

	

	}

}
