package com.educacionit.clase3;

public class Persona {
	int dni = 36863;
	String Nombre = "alex";
	String apellido =  "de assis";
	

	public String toString() {
		return "Persona [dni=" + dni + ", Nombre=" + Nombre + ", apellido=" + apellido + "]";
	}
	
	

}
